create database railway
