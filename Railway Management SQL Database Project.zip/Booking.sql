use railway

create table Booking(

CustomerID int primary key,
BookingStation varchar(20),
Class varchar(20),
No_of_Seats int,
BookingDate date,
Travel_Destination varchar(20),
From_Destination varchar(20)

)

insert into Booking
Values
(902, 'pishawar', 'B', 4, '2020-8-10', 'lahore'),
(903, 'lahore', 'B', 4, '2020-9-6', 'karachi'),
(904, 'lahore', 'A', 2, '2020-9-8', 'islamabad'),
(905, 'multan', 'B', 6, '2020-9-10', 'kamalia'),
(906, 'karachi', 'B', 10, '2020-8-8', 'lahore'),
(907, 'lahore', 'B', 5, '2020-8-8', 'islamabad')

