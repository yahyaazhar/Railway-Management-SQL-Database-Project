use railway
create table Train1
(
Train_name nvarchar(30) not null ,
Train_code int not null primary key,
Start_destination varchar(30) not null,
End_destination varchar(30) not null,
Start_time varchar(30) not null,
End_time varchar(30) not null,
Track_no int not null,
Train_type varchar(30),
Train_class varchar(30),
Current_status varchar(30),
Arrival_time varchar(30)
)

insert into Train1
values
('travels',101,' islamabad','shahdara', '12:34' ,'5:38',001,'engine','A','on route','2:38'),
('shalimaar',102,' De Haan','murree', '2:34' ,'7:38',002,'bullet','A','on wait','3:38'),
('shalimaar',103,' abbotabad','rawalpindi', '11:34' ,'9:38',003,'engine','B','on route','8:38'),
('travels',104,' gujranwala','LAHORE', '1:34' ,'2:38',004,'engine','A','on wait','2:38'),
('niazi',105,' islamabad','shahdara', '10:34' ,'9:38',005,'auto','B','on route','5:38'),
('shalimaar',106,' De Haan','sheikhupura', '9:34' ,'2:38',006,'engine','A','on wait','9:38'),
('niazi',107,' sargodha','LAHORE', '12:34' ,'2:38',007,'engine','B','on wait','2:38'),
('shalimaar',108,' karachi','pashawar', '7:34' ,'2:38',008,'bullet','A','on route','2:38'),
('niazi',109,' De Haan','LAHORE', '8:34' ,'2:38',009,'engine','A','on wait','11:38'),
('shalimaar',110,' lahore','karachi', '2:34' ,'5:38',010,'auto','B','on route','7:38');

select *from Train1
