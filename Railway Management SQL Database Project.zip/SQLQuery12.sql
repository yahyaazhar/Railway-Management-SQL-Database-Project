use railway

create table Track
(
Track_no int not null identity,
Train_id int not null,
no_of_trains int not null,
free_time varchar(30)
Foreign Key(Train_id) REFERENCES Train1(Train_code)
)

insert into Track(Train_id,no_of_trains,free_time)
values
(40,5,'1 hr'),
(41,1,'1 hr'),
(42,4,'1 hr'),
(43,5,'1 hr'),
(47,3,'1 hr'),
(44,5,'1 hr'),
(45,3,'1 hr'),
(46,2,'1 hr')

select *from Track
