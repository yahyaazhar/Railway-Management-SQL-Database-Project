use railway
create table Station_management
(
St_mastername varchar(30),
St_masterid int not null primary key identity,
)

insert into Station_management(St_mastername)
values
('bilal'),
('noman'),
('yahya'),
('bilal'),
('noor'),
('bilal'),
('abubakar'),
('sayyam'),
('ali')
 select *from Station_management