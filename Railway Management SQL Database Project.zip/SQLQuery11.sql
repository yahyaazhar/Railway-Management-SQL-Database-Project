use railway
create table Cityname
(
City_code int not null primary key identity,
City_name varchar(30)
)

insert into Cityname(City_name)
values
('sargodha'),
('islamabad'),
('lahore'),
('karachi'),
('lahore'),
('lahore'),
('gujranwala'),
('faislabad')

select *from Cityname

