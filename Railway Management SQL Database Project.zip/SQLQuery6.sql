use railway
create table Station
(
St_name varchar(30),
St_code int not null primary key,
Train_name varchar(30),
Train_id int not null,
Arrival_time varchar(30),
Track_no int not null unique,
Stay_time varchar(30)
Foreign key(Train_id) REFERENCES Train1(Train_code), 
);

insert into Station
values
('gujranwala',900,'express',31, '12:34' ,70,'1.35 hr'),
('lahore',901,'shalimar',32, '12:34' ,71,'8.5 hr'),
('gujranwala',902,'niazi',33, '1:34' ,72,'9.5 hr'),
('lahore',903,'express',34, '2:34' ,73,'2.5 hr'),
('rawalpindi',904,'new',35, '12:34' ,74,'1.25 hr'),
('gujranwala',905,'railways',36, '12:34' ,76,'1.5 hr'),
('karachi',906,'express',37, '11:34' ,77,'3.5 hr'),
('lahore',907,'niazi',38, '5:34' ,78,'1.5 hr'),
('islamabad',908,'express',39, '8:34' ,79,'7.5 hr'),
('gujranwala',909,'railways',30, '3:34' ,75,'1.5 hr')
