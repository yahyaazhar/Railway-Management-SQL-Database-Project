use railway
create table Citiesname
(
City_name varchar(30) not null,
Station_code int not null identity
FOREIGN KEY(Station_code) REFERENCES Station(St_code)
);

insert into Citiesname(City_name)
values
('lahore'),
('faislabad'),
('okara'),
('lahore'),
('rawalpindi'),
('lahore'),
('shahdara'),
('islamabad'),
('lahore')

select *from Citiesname