use railway
create table Timing
(
St_name varchar(30),
St_id int not null,
Arrival_time varchar(30),
Departure_time varchar(30)
FOREIGN KEY(St_id) REFERENCES Station(St_code)
)

insert into Timing
values
('lahore',50,'12:34','12:56'),
('karachi',51,'2:34','9:56'),
('lahore',52,'11:34','7:56'),
('islamabad',53,'9:34','5:56'),
('rawalpindi',54,'12:34','3:56'),
('lahore',55,'11:34','9:56'),
('karachi',56,'10:34','8:56'),
('sargodha',57,'12:34','9:56')

select *from Timing