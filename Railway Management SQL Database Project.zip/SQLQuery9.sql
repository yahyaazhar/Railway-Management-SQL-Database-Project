use railway
create table Train_class
(
Class_name varchar(30) not null,
Class_status varchar(30)
)
insert into Train_class
values
('business','A'),
('economy','A'),
('business','A'),
('economy','B'),
('business','A'),
('economy','B'),
('business','A'),
('economy','B'),
('economy','B')

select *from Train_class

select Class_name
from Train_class
