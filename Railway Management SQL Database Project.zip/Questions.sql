

select * from Booking

select * from Customer

select book.Travel_Destination, book.BookingDate, cus.Customer_name, cus.Station_name 
from Booking as book
right join Customer as cus on book.Travel_Destination = cus.Station_name


select * from Timing

select * from Station

select * from Train1


select *
from  Customer
right join Booking on Customer.Departure_date = Booking.BookingDate
where Customer.Reg_seats >= 4


select * from Station_management
select * from Salaries

select * from Cityname
select * from Citiesname



select * 
from Station
inner join Train1 on Station.Arrival_time = Train1.Arrival_time


alter table Booking
Add Foreign Key (Train_Code) References Train1(Train_code)

Select * from Booking




select Booking.Travel_Destination
from Booking
where Booking.CustomerID In (

   Select Customer.Customer_id
   from Customer
   where Customer.Reg_seats > 3 

);


Select Train1.Train_code, Train1.Train_name
from Train1
where Train1.End_destination in ( 

    select Booking.Travel_Destination
    from Booking
    where Booking.CustomerID In (

              Select Customer.Customer_id
              from Customer
              where Customer.Reg_seats > 3 

   )
);


select * from Train1



select * from Track
Select * from Train1
select * from Station



select Station.St_name, Station.St_code
from Station 
where Station.Track_no in (
    select Track.Track_no
    from Track 
    where Track.Train_id in (

      select Train1.Train_code
      from Train1

   )
)



select Track.Track_no
    from Track 
    where Track.Train_id in (

      select Train1.Train_code
      from Train1

   )


select * from Train1
