use railway
create table Customer
(
Customer_id int not null primary key,
Customer_name varchar(30),
Reg_trainid int not null,
Reg_seats int not null,
Station_name varchar(30),
Departure_date date not null,
foreign key(Reg_trainid) REFERENCES Train1(Train_code)
)

insert into Customer
values
(900,'mooez',30, 2 ,'lahore','2020-02-22'),
(901,'bilal',31, 2 ,'karachi','2020-03-22'),
(902,'noor',32, 8 ,'lahore','2020-05-17'),
(903,'ali',33, 4 ,'islamabad','2020-08-22'),
(904,'mooez',34, 2 ,'lahore','2020-02-8'),
(905,'noman',35, 8 ,'karachi','2020-06-29'),
(906,'arslan',36, 10 ,'lahore','2020-08-10'),
(907,'haris',37, 5 ,'rawalpindi','2020-11-13'),
(908,'waseem',38, 3 ,'karachi','2020-12-10')

select *from Customer