use railway
create table Salaries
(
Post_name varchar(30) not null,
Salary int not null,
post_id int not null identity
)

insert into Salaries(Post_name,Salary)
values
('manager',60000),
('manager2',50000),
('ticket checker2',30000),
('cleaner',10000),
('executive manager',80000),
('ticket checker',10000),
('cleaner2',15000),
('keeper',5000),
('securit guard',10000)
 
 select *from Salaries

